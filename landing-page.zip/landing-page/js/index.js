// const sections = document.querySelectorAll("section")
// const nav = document.querySelectorAll("nav .navbar")

// window.onscroll = () => {
//   let current = ''

//   const bottomOfWindow =
//             document.documentElement.scrollTop + window.innerHeight ===
//             document.documentElement.offsetHeight

//             console.log(bottomOfWindow);
            
//   if (bottomOfWindow) {
//     document.querySelectorAll("nav .navbar").style.background-color="red";
//   }
// }

// $(document).ready(function(){
//   $(window).scroll(function(){
//   	var scroll = $(window).scrollTop();
// 	  if (scroll > 300) {
// 	    $(".black").css("background" , "blue");
// 	  }

// 	  else{
// 		  $(".black").css("background" , "#333");  	
// 	  }
//   })
// })